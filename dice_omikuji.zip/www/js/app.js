// This is a JavaScript file

function omikuji (){
    var dice = Math.floor(Math.random() * 6);
    var image_name;
    if (dice == 0) {
        image_name = "dice1.png";
    } else if  (dice == 1) {
        image_name = "dice2.png";
    } else if (dice == 2) {
        image_name = "dice3.png";
    } else if (dice == 3) {
        image_name = "dice4.png";
    } else if (dice == 4) {
        image_name = "dice5.png";
    } else {
        image_name = "dice6.png";
    }

    document.getElementById("saisyo").style["display"] = "none";
    document.getElementById("kekka").src = "images/" + image_name;
    document.getElementById("kekka").style["display"] = "inline";
    document.getElementById("button").src = "images/omikuji-btn-yarinaosu.png";
}

