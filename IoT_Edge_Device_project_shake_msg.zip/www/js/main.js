let SensorInfo = {}; //Measurement values
let TimerID = "";  //Timer ID for updating sensors
let UPTimerID = "";  //Timer ID for uplading
let Thing = "";   //Thing name of this device
let isUploading = 0; //State of upload. 0:stop, 1:active
let noLocation = true; //Store geolocation privacy setting

let isUpdatedSensors = 0;  //State of updating sensors. 0:not change, 1:updated

let acc_pre;    //previous acceleration magnitude
let acc_th = 11;    //Threshold of accerlation magnitude

//Tap Sensor Button 
function SensorBtn() {
   
    if (TimerID != "") {
        //stop measurement
        clearInterval(TimerID);
        TimerID = "";
        document.getElementById("Sensor").innerText = "inactive";
        document.getElementById("SensorBtn").innerText = "Start measurement";
        sec = 0;
        ped_pre = 0;
    }
    else {
        //start measurement
        SensorInfo = {};
        isUpdatedSensors = 0;
        TimerID = setInterval(updateSensors, 100);
        document.getElementById("Sensor").innerText = "active";
        document.getElementById("SensorBtn").innerText = "Stop measurement";
        SensorInfo.pedometer=0;
        SensorInfo.shake=0;

    }
}

//Functions related sensors
//Update sensor values
function updateSensors() {
    noLocation = document.getElementById("locationFlg").checked;
    
    //accelerometer
    if ("accelerometer" in navigator) {
        navigator.accelerometer.getCurrentAcceleration(accSuccess, accError);
    } else {
        //Update table
        document.getElementById("acc_x").innerText = "No sensor";
        document.getElementById("acc_y").innerText = "No sensor";
        document.getElementById("acc_z").innerText = "No sensor";
    }

    if ("compass" in navigator && noLocation == false) {
        navigator.compass.getCurrentHeading(compSuccess, compError);
    } else {
        SensorInfo.com = "No sensor";
        //Update table
        document.getElementById("com").innerText = "No sensor";
    }

    if ("geolocation" in navigator && noLocation == false) {
        navigator.geolocation.getCurrentPosition(geoSuccess, geoError);
    } else {
        SensorInfo.geo_lon = "No sensor";
        SensorInfo.geo_lat = "No sensor";
        //Update table
        document.getElementById("geo_lon").innerText = "No sensor";
        document.getElementById("geo_lat").innerText = "No sensor";
    }
}

function accSuccess(acceleration) {
    SensorInfo.acc_x = Math.round(acceleration.x * 1000) / 1000;
    SensorInfo.acc_y = Math.round(acceleration.y * 1000) / 1000;
    SensorInfo.acc_z = Math.round(acceleration.z * 1000) / 1000;
    
    //Update table
    document.getElementById("acc_x").innerText = SensorInfo.acc_x;
    document.getElementById("acc_y").innerText = SensorInfo.acc_y;
    document.getElementById("acc_z").innerText = SensorInfo.acc_z;

    isUpdatedSensors = 1;
    pedometer();
}

function compSuccess(input) {
    SensorInfo.com = Math.round(input.magneticHeading * 1000) / 1000;
    
    //Update table
    document.getElementById("com").innerText = SensorInfo.com;

    isUpdatedSensors = 1;
}

function geoSuccess(input) {
    SensorInfo.geo_lon = Math.round(input.coords.longitude * 1000) / 1000;
    SensorInfo.geo_lat = Math.round(input.coords.latitude * 1000) / 1000;    
    //
    
    //Update table
    document.getElementById("geo_lon").innerText = SensorInfo.geo_lon;
    document.getElementById("geo_lat").innerText = SensorInfo.geo_lat;

    isUpdatedSensors = 1;
}

function accError() {
    console.log("Error receiving accleration data.")
}

function compError() {
    console.log("Error receiving compass data.")
}

function geoError() {
    console.log("Error receiving geolocation data.")
}

//Upload the mesurement to cloud
function doUpload() {
        startUpload();  //start uploading
}

//Start uploading
function startUpload() {
    isUploading = 0;
    Thing = document.getElementById("thing").value;
    if (Thing != "") {
        isUploading = 1;
    }
    if (isUploading == 1) {
        document.getElementById("cloud_state").innerText = "connected";
        UPTimerID = setInterval(pushSensors, 1000); //1 second
    }
    else {
        alert("Input a thing name.");
        document.getElementById("cloudStop").checked=true;
    }
}

//Stop uploading
function stopUpload() {
    isUploading = 0;
    document.getElementById("cloud_state").innerText = "disconnected";
    if (UPTimerID != "") {
        clearInterval(UPTimerID);
        UPTimerID = "";
    }
}

//Upload the mesurement to cloud
function pushSensors() {
    if (isUpdatedSensors) {
        isUpdatedSensors = 0;
        Upload2Dweetio(Thing, SensorInfo);
        console.log("ACC_MAG: ",SensorInfo.acc_mag);
        console.log("PEDO: ", SensorInfo.pedometer);
        SensorInfo.shake = 0;
    }
}

//Upload to dweet.io
function Upload2Dweetio(thing, sensors) {
    dweetio.dweet_for(thing, sensors, function(err, dweet){
        if(err === undefined) {
            console.log(dweet.thing); // "my-thing"
            console.log(dweet.content); // The content of the dweet
            console.log(dweet.created); // The create date of the dweet
        } else {
            console.log(err);
        }
    });
}

//pedometer
function pedometer() {
    SensorInfo.acc_mag = Math.round(Math.sqrt((SensorInfo.acc_x ** 2)+(SensorInfo.acc_y ** 2)+(SensorInfo.acc_z ** 2)) * 1000) / 1000;
    if((SensorInfo.acc_mag >= acc_th) && (acc_pre < acc_th)){
        ped_pre = SensorInfo.pedometer;
        SensorInfo.pedometer++;
        SensorInfo.shake = 1;
    }
    acc_pre = SensorInfo.acc_mag;
}
